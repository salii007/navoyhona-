// src/pages/Login.jsx
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const { data } = await axios.post(`${import.meta.env.VITE_API_URL}/auth/login`, {
        username,
        password,
      });

      // 🔐 Token va rolni localStorage'ga saqlash
      if (data.role === 'courier') {
        localStorage.setItem('courierToken', data.token);
        localStorage.setItem('role', 'courier');
        navigate('/courier', { replace: true });
      } else if (data.role === 'tablet') {
        localStorage.setItem('token', data.token);
        localStorage.setItem('role', 'tablet');
        navigate('/zakazlar', { replace: true });
      } else {
        setError("Noma'lum foydalanuvchi roli");
      }

    } catch (err) {
      console.error("❌ Login xatosi:", err);
      setError('Login yoki parol noto‘g‘ri');
    }
  };

  return (
    <div className="p-4 max-w-sm mx-auto mt-20">
      <h2 className="text-2xl font-bold mb-4 text-center">🔐 Tizimga kirish</h2>

      {error && (
        <div className="text-red-500 bg-red-100 border border-red-300 p-2 mb-4 rounded">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Login"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="w-full p-3 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
        <input
          type="password"
          placeholder="Parol"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full p-3 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white p-3 rounded font-semibold transition duration-200"
        >
          Kirish
        </button>
      </form>
    </div>
  );
}
