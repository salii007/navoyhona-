import { useEffect, useState } from 'react';
import ZakazCard from '../components/ZakazCard';
import Navbar from '../../common/Navbar';

function ZakazlarCourier() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [error, setError] = useState(null);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('courierToken');
      if (!token) {
        console.error("❌ Token topilmadi");
        setLoading(false);
        return;
      }
      
  
      const res = await fetch('http://localhost:3000/api/scheduled-orders/today', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
  
      if (!res.ok) {
        throw new Error(`Server xatosi: ${res.status}`);
      }
  
      const data = await res.json();
      if (Array.isArray(data)) {
        setOrders(data);
      } else {
        console.error("Kutilgan massiv emas:", data);
        setOrders([]);
      }
    } catch (err) {
      console.error("Zakazlarni olishda xatolik:", err);
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };
  

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleAction = async (orderId, action, value) => {
    let url = `${import.meta.env.VITE_API_URL}/courier/orders/${orderId}/${action}`;
    let options = {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('courierToken')}`,
      }
    };

    if (action === 'payment') {
      options.body = JSON.stringify({ payment_type: value });
    }

    try {
      const res = await fetch(url, options);
      const updated = await res.json();
      console.log('Yangilandi:', updated);
      fetchOrders();
    } catch (err) {
      console.error('Tugma bajarishda xato:', err);
    }
  };

  if (loading) {
    return <p className="text-center mt-10 text-gray-500">Yuklanmoqda...</p>;
  }

  if (error) {
    return <p className="text-center text-red-500">{error}</p>;
  }

  const filteredOrders = orders.filter(order => {
    if (filter === 'all') return true;
    return order.status === filter;
  });

  return (
    <div className="p-4 space-y-4">
      <Navbar />

      <div className="flex flex-wrap gap-2 justify-center mb-4">
        {[
          { label: '📦 Hammasi', value: 'all' },
          { label: '⏳ Kutilmoqda', value: 'pending' },
          { label: '🚚 Qabul qilindi', value: 'accepted' },
          { label: '📤 Yo‘lda', value: 'picked_up' },
          { label: '✅ Tugagan', value: 'completed' }
        ].map(({ label, value }) => (
          <button
            key={value}
            onClick={() => setFilter(value)}
            className={`px-4 py-1 rounded-full border text-sm font-medium transition-all duration-200 ${
              filter === value
                ? 'bg-blue-600 text-white shadow'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-blue-50'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {filteredOrders.length === 0 ? (
        <p className="text-center text-gray-400">Bu kategoriyada zakazlar yo‘q</p>
      ) : (
        filteredOrders.map(order => (
          <ZakazCard key={order.id} order={order} onAction={handleAction} />
        ))
      )}
    </div>
  );
}

export default ZakazlarCourier;
