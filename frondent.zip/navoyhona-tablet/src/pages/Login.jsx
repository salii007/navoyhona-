import axios from '../axiosConfig'; // ✅ SOZLANGAN instansiyani chaqiramiz
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/auth/login', { phone, password });
      localStorage.setItem('token', response.data.token);
      navigate('/zakazlar');
    } catch (error) {
      console.error('Login xatosi:', error);
      alert('Login muvaffaqiyatsiz! Telefon yoki parol noto‘g‘ri.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <form onSubmit={handleLogin} className="bg-white p-6 rounded shadow-md w-80 space-y-4">
        <input
          type="text"
          placeholder="Telefon raqam"
          className="border p-2 w-full rounded"
          value={phone}
          onChange={e => setPhone(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Parol"
          className="border p-2 w-full rounded"
          value={password}
          onChange={e => setPassword(e.target.value)}
          required
        />
        <button type="submit" className="bg-blue-500 text-white p-2 rounded w-full">
          Kirish
        </button>
      </form>
    </div>
  );
}

export default Login;
