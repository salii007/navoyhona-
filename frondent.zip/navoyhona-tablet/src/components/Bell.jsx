// src/components/ui/Bell.jsx
import React, { useEffect, useState } from 'react';
import axios from '../axiosConfig';
import ZakazReminderModal from './ZakazReminderModal';

function Bell({ token }) {
  const [orders, setOrders] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    const fetchToday = () => {
      axios.get('/scheduled-orders/today', {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => setOrders(res.data))
      .catch(err => console.error("Bell zakaz olishda xatolik:", err));
    };
    fetchToday();
    const iv = setInterval(fetchToday, 60 * 1000);
    return () => clearInterval(iv);
  }, [token]);

  const now = new Date();
  const filtered = orders.filter(o => {
    const dt = new Date(`${o.date}T${o.time}`);
    const diff = (dt - now) / 60000;
    return diff > 0 && diff <= 40 && o.status !== 'delivered';
  });

  return (
    <div>
      {filtered.length > 0 && (
        <div
          onClick={() => setModalOpen(true)}
          style={{ color: 'red', fontSize: '24px', cursor: 'pointer' }}
        >
          🔔
        </div>
      )}
      {modalOpen && (
        <ZakazReminderModal zakazlar={filtered} onClose={() => setModalOpen(false)} />
      )}
    </div>
  );
}

export default Bell;
