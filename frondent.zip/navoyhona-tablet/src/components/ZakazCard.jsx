import { useState } from 'react';
import axios from '../axiosConfig'; // ✅ Sozlangan axios

function ZakazCard({ order, isAdmin }) {
  const [open, setOpen] = useState(false);
  const [delivered, setDelivered] = useState(order.status === 'delivered');
  const [showConfirm, setShowConfirm] = useState(false);

  const {
    id, name, phone, address,
    product_name, quantity,
    unit_price, price,
    zalog_type, zalog_amount = 0,
    date, time,
    created_at,
    lat, lng
  } = order;

  // 📅 Sana formatlash
  const formattedDate = new Date(date).toLocaleDateString('uz-UZ', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });

  // 🕓 Soat formatlash
  const formattedTime = `${time?.slice(0, 5) || '00:00'}`;

  const perItem = unit_price ?? price ?? 0;
  const total = perItem * quantity;
  const remaining = total - zalog_amount;

  const getDifferenceInMinutes = (dateStr, timeStr) => {
    const [hours, minutes] = timeStr.split(':');
    const target = new Date(dateStr);
    target.setHours(+hours);
    target.setMinutes(+minutes);
    target.setSeconds(0);
    return (target - new Date()) / (1000 * 60);
  };

  const diffMin = getDifferenceInMinutes(date, time);
  const canDeliver = diffMin <= 40;

  const navigateTo = e => {
    e.stopPropagation();
    if (lat && lng) {
      window.open(`https://yandex.uz/maps/?rtext=~${lat},${lng}`, '_blank');
    } else {
      alert('Geolokatsiya mavjud emas!');
    }
  };

  const confirmDelivery = async () => {
    try {
      await axios.patch(`/scheduled-orders/${id}/delivered`);
      setDelivered(true);
      setShowConfirm(false);
    } catch (err) {
      alert("❌ Xatolik: zakazni 'delivered' qilishda muammo bo‘ldi.");
      console.error(err);
    }
  };

  if (delivered) return null;

  return (
    <div className="bg-white p-4 rounded shadow cursor-pointer relative" onClick={() => setOpen(!open)}>
      <div className="font-semibold text-lg">
        📛 {name}
        <div className="text-sm text-gray-600 mt-1">
          📅 Yetkazish: <strong>{formattedDate}</strong> 🕓 <strong>{formattedTime}</strong>
        </div>
        {isAdmin && created_at && (
          <div className="text-xs text-gray-400">
            🕓 Zakaz berilgan: {new Date(created_at).toLocaleString()}
          </div>
        )}
      </div>

      {open && (
        <div className="mt-2 space-y-1 text-sm">
          <div>📞 {phone}</div>
          <div>📍 {address}</div>
          <div>🍞 {product_name || 'non'} — {quantity} ta</div>

          {zalog_type === 'bor' && (
            <>
              <div className="text-blue-600">💰 Zalog: {zalog_amount.toLocaleString()} so‘m</div>
              <div className="text-red-600 font-semibold">💸 Qolgan: {remaining.toLocaleString()} so‘m</div>
            </>
          )}

          <div className="flex flex-col sm:flex-row gap-2 mt-3">
            <button onClick={navigateTo} className="bg-purple-600 text-white px-3 py-1 rounded hover:bg-purple-700">
              🧭 Navigator orqali borish
            </button>

            {canDeliver && (
              <button
                onClick={e => {
                  e.stopPropagation();
                  setShowConfirm(true);
                }}
                className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
              >
                ✅ Yetkazdim
              </button>
            )}
          </div>
        </div>
      )}

      {/* ✅ MODAL OYNA */}
      {showConfirm && (
        <div style={{
          position: 'fixed',
          top: '0',
          left: '0',
          width: '100vw',
          height: '100vh',
          backgroundColor: 'rgba(0,0,0,0.5)',
          zIndex: 9999,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <div style={{
            backgroundColor: '#fff',
            padding: '20px',
            borderRadius: '10px',
            textAlign: 'center'
          }}>
            <p>Modal ochildi! Zakaz yetkazildimi?</p>
            <button
              className="bg-green-600 text-white px-3 py-1 rounded mr-2"
              onClick={confirmDelivery}
            >
              Ha
            </button>
            <button
              className="bg-gray-400 text-white px-3 py-1 rounded"
              onClick={() => setShowConfirm(false)}
            >
              Yo‘q
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default ZakazCard;
