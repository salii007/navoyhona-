import { Link } from 'react-router-dom';
import LogoutButton from './LogoutButton.jsx';
import BellNotification from './Bell.jsx';
import Clock from './Clock';

function Navbar() {
  return (
    
    <div className="bg-white shadow p-4 flex justify-between items-center">
      {/* Chap taraf: logotip va soat */}
      <div className="flex items-center gap-4">
        <h1 className="text-xl font-bold">📋 Navoyhona Zakazlar</h1>
        <Clock />
      </div>

      {/* O‘ng taraf: tugmalar */}
      <div className="flex items-center gap-6">
        {/* 🔔 Bildirishnoma */}
        <BellNotification />

        {/* 🧭 Navigatsiya tugmalari */}
        <Link to="/zakazlar" className="text-blue-600 hover:underline">
          Zakazlar
        </Link>
        <Link to="/qaytarilgan-nonlar" className="font-semibold">
          🔁 Qaytarilgan nonlar
        </Link>
        <Link to="/create-zakaz" className="text-green-600 hover:underline">
          Yangi Zakaz
        </Link>

        {/* 🔒 Chiqish tugmasi */}
        <LogoutButton />
      </div>
    </div>
  );
}

export default Navbar;
