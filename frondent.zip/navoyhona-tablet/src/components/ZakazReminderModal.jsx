import { useEffect, useState } from 'react';
import axios from 'axios';

export default function ZakazReminderModal({ show, onClose }) {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (!show) return;

    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return;

        const res = await axios.get('/api/scheduled-orders', {
          headers: { Authorization: `Bearer ${token}` }
        });

        const now = new Date();
        const in40Min = new Date(now.getTime() + 40 * 60000);

        const filtered = res.data.filter(order => {
          const deliveryTime = new Date(order.delivery_time);
          return deliveryTime > now && deliveryTime <= in40Min;
        });

        setOrders(filtered);
      } catch (err) {
        console.error('Modal load error:', err);
      }
    };

    fetchData();
  }, [show]);

  if (!show) return null;

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <h2 className="text-lg font-bold mb-2">⏰ 40 daqiqadan kam qolgan zakazlar</h2>
        {orders.length === 0 ? (
          <p>Hozircha eslatmalar yo‘q.</p>
        ) : (
          <ul>
            {orders.map(order => (
              <li key={order.id} className="border-b py-1">
                <strong>{order.client_name}</strong> — {new Date(order.delivery_time).toLocaleTimeString()}
              </li>
            ))}
          </ul>
        )}
        <button onClick={onClose} className="mt-3 btn">Yopish</button>
      </div>
    </div>
  );
}
