import { useNavigate } from 'react-router-dom';

function LogoutButton() {
  const nav = useNavigate();
  return <button onClick={() => { localStorage.removeItem('token'); nav('/'); }} className="text-red-500 hover:underline">Chiqish</button>;
}

export default LogoutButton;