import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Zakazlar from './pages/Zakazlar.jsx';
import CreateZakaz from './pages/CreateZakaz.jsx';
import KelajakZakazlar from './pages/KelajakZakazlar.jsx';
import QaytarilganNonlar from './pages/QaytarilganNonlar';

function App() {
  const token = localStorage.getItem('token');

  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/zakazlar" element={token ? <Zakazlar /> : <Navigate to="/" replace />} />
      <Route path="/create-zakaz" element={token ? <CreateZakaz /> : <Navigate to="/" replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
      <Route path="/kelajak-zakazlar" element={<KelajakZakazlar />} />
      <Route path="/qaytarilgan-nonlar" element={<QaytarilganNonlar />} />
      
    </Routes>
  );
}

export default App;
