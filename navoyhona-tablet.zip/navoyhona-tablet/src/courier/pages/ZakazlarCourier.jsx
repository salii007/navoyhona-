import { useEffect, useState } from 'react';
import ZakazCard from '../components/ZakazCard';
import Navbar from '../../common/Navbar';

export default function ZakazlarCourier() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [error, setError] = useState(null);

  // ✅ Zakazlarni olib kelish
  const fetchOrders = async () => {
    setLoading(true);
    const token = localStorage.getItem('courierToken');
    console.log('🔐 Token:', token); // foydali log

    if (!token) {
      console.error("❌ Token topilmadi");
      setError("Token topilmadi. Qayta login qiling.");
      setLoading(false);
      return;
    }

    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/scheduled-orders/today`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        throw new Error(`Server xatosi: ${res.status}`);
      }

      const data = await res.json();
      console.log('📦 Zakazlar keldi:', data);
      setOrders(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("❌ Zakazlarni olishda xatolik:", err);
      setError("Server bilan bog‘lanishda xatolik yuz berdi.");
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  // ✅ Harakat tugmalari uchun
  const handleAction = async (orderId, action, value) => {
    const token = localStorage.getItem('courierToken');
    if (!token) return alert("Token topilmadi. Qayta login qiling.");

    const url = `${import.meta.env.VITE_API_URL}/courier/orders/${orderId}/${action}`;
    const options = {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: action === 'payment' ? JSON.stringify({ payment_type: value }) : undefined,
    };

    try {
      const res = await fetch(url, options);
      const updated = await res.json();
      console.log('✅ Yangilangan zakaz:', updated);
      fetchOrders();
    } catch (err) {
      console.error('❌ Tugma bajarishda xato:', err);
    }
  };

  // ✅ Status va mahsulot bo‘yicha bitta filtr
  const productNames = [...new Set(orders.map(order => order.product_name))];
  const statusFilters = [
    { label: '📦 Hammasi', value: 'all' },
    { label: '⏳ Kutilmoqda', value: 'pending' },
    { label: '🚚 Qabul qilindi', value: 'accepted' },
    { label: '📤 Yo‘lda', value: 'picked_up' },
    { label: '✅ Tugagan', value: 'completed' }
  ];

  const filteredOrders = orders.filter(order => {
    if (filter === 'all') return true;
    return order.status === filter || order.product_name === filter;
  });

  return (
    <div className="p-4 space-y-4">
      <Navbar />

      {/* 🔘 Filtrlar */}
      <div className="flex flex-wrap gap-2 justify-center mb-4">
        {[...statusFilters, ...productNames.map(name => ({ label: name, value: name }))].map(({ label, value }) => (
          <button
            key={value}
            onClick={() => setFilter(value)}
            className={`px-3 py-1 rounded-full border text-sm font-medium transition-all ${
              filter === value
                ? 'bg-blue-600 text-white shadow'
                : 'bg-white text-gray-700 border-gray-300 hover:bg-blue-100'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="text-center text-gray-500">⏳ Yuklanmoqda...</p>
      ) : error ? (
        <p className="text-center text-red-500">{error}</p>
      ) : filteredOrders.length === 0 ? (
        <p className="text-center text-gray-400">Bu kategoriyada zakazlar yo‘q</p>
      ) : (
        filteredOrders.map(order => (
          <ZakazCard key={order.id} order={order} onAction={handleAction} />
        ))
      )}
    </div>
  );
}
