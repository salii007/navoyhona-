const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');

// 🛰️ Dastavkachi joylashuvini yuboradi
router.patch('/position', auth, role('courier'), async (req, res) => {
  const userId = req.user.id;
  const { latitude, longitude } = req.body;

  try {
    await db.query(`
      UPDATE users
      SET latitude = $1,
          longitude = $2,
          last_seen = NOW()
      WHERE id = $3
    `, [latitude, longitude, userId]);

    res.json({ message: 'Joylashuv yangilandi' });
  } catch (err) {
    console.error('Lokatsiya xatosi:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// 🌍 Admin barcha dastavkachilarni joylashuvini ko‘radi
router.get('/locations', auth, role('admin'), async (req, res) => {
  try {
    const result = await db.query(`
      SELECT id, name, latitude, longitude, last_seen
      FROM users
      WHERE role = 'courier'
    `);
    res.json(result.rows);
  } catch (err) {
    console.error('Joylashuvlar xatosi:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
