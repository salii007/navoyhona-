const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');

// 🧾 Admin — barcha qaytarilgan nonlar ro‘yxati
router.get('/', auth, role('admin'), async (req, res) => {
  try {
    const { is_received } = req.query;

    let query = `SELECT * FROM returns`;
    if (is_received === 'true') query += ` WHERE is_received = true`;
    else if (is_received === 'false') query += ` WHERE is_received = false`;

    query += ` ORDER BY returned_at DESC`;

    const result = await db.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error('Admin returns xatosi:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
