const express = require('express');
const router = express.Router();
const pool = require('../db');
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');


// 🔵 Bugungi zakazlar (Toshkent vaqti bo‘yicha)
router.get('/today', auth, async (req, res) => {
  const locationId = req.user.location_id;
  const query = `
    SELECT *
    FROM scheduled_orders
    WHERE location_id = $1
      AND date = (now() AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Tashkent')::date
    ORDER BY time ASC
  `;
  try {
    const { rows } = await pool.query(query, [locationId]);
    res.json(rows);
  } catch (err) {
    console.error('GET /scheduled-orders/today error:', err);
    res.status(500).json({ error: 'Server xatoligi' });
  }
});



// 🟣 Kelajak zakazlar (Toshkent vaqti bo‘yicha)
router.get('/future', auth, async (req, res) => {
  const locationId = req.user.location_id;
  const query = `
    SELECT *
    FROM scheduled_orders
    WHERE location_id = $1
      AND date > (now() AT TIME ZONE 'UTC' AT TIME ZONE 'Asia/Tashkent')::date
    ORDER BY date ASC, time ASC
  `;
  try {
    const { rows } = await pool.query(query, [locationId]);
    res.json(rows);
  } catch (err) {
    console.error('GET /scheduled-orders/future error:', err);
    res.status(500).json({ error: 'Server xatoligi' });
  }
});





// 3️⃣ POST /scheduled-orders → yangi zakaz qo‘shish
router.post('/', auth, async (req, res) => {
  const locationId = req.user.location_id;
  const {
    name, phone, address, date, time,
    quantity, product_name, price,
    zalog_amount, zalog_type
  } = req.body;

  try {
    const result = await pool.query(
      `INSERT INTO scheduled_orders 
       (name, phone, address, date, time, quantity, location_id, status, product_name, price, zalog_amount, zalog_type) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'pending', $8, $9, $10, $11) 
       RETURNING *`,
      [name, phone, address, date, time, quantity, locationId, product_name, price, zalog_amount, zalog_type]
    );

    res.status(201).json({ message: 'Zakaz qo‘shildi', order: result.rows[0] });
  } catch (err) {
    console.error('❌ POST /scheduled-orders error:', err);
    res.status(500).json({ error: 'Server xatoligi' });
  }
});

// 4️⃣ PATCH /scheduled-orders/:id/delivered → yetkazilgan deb belgilash
router.patch('/:id/delivered', auth, async (req, res) => {
  const { id } = req.params;
  const locationId = req.user.location_id;

  try {
    const result = await pool.query(
      `UPDATE scheduled_orders 
       SET status = 'delivered', delivered_at = NOW()
       WHERE id = $1 AND location_id = $2 
       RETURNING *`,
      [id, locationId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Zakaz topilmadi yoki sizga tegishli emas' });
    }

    res.json({ message: 'Zakaz delivered deb belgilandi', order: result.rows[0] });
  } catch (err) {
    console.error('❌ PATCH /:id/delivered xatolik:', err);
    res.status(500).json({ error: 'Server xatoligi' });
  }
});

// 5️⃣ DELETE /scheduled-orders/:id → faqat admin delivered zakazni o‘chiradi
router.delete('/:id', auth, role('admin'), async (req, res) => {
  const { id } = req.params;

  try {
    const zakaz = await pool.query('SELECT * FROM scheduled_orders WHERE id = $1', [id]);
    if (zakaz.rows.length === 0) {
      return res.status(404).json({ error: 'Zakaz topilmadi' });
    }

    if (zakaz.rows[0].status !== 'delivered') {
      return res.status(400).json({ error: 'Zakaz hali yetkazilmagan, o‘chirib bo‘lmaydi' });
    }

    await pool.query('DELETE FROM scheduled_orders WHERE id = $1', [id]);
    res.json({ message: 'Zakaz admin tomonidan o‘chirildi' });
  } catch (err) {
    console.error('❌ DELETE /:id xatolik:', err);
    res.status(500).json({ error: 'Server xatoligi' });
  }
});

module.exports = router;
